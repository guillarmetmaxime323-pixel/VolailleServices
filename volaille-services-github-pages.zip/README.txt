# Déploiement rapide sur GitHub Pages (sans Git)

1. Créez un compte GitHub (si besoin) : https://github.com/join
2. Cliquez sur **New repository**.
   - *Repository name* : `volaille-services`
   - **Public** → cliquez **Create repository**
3. Dans la page du dépôt, cliquez **Add file → Upload files**.
4. Glissez **index.html** ici puis **Commit changes**.
5. Allez dans **Settings → Pages**.
   - *Build and deployment* : **Deploy from a branch**
   - *Branch* : **main** et **/** (root), cliquez **Save**.
6. Attendez le message **"Your site is live"**.
   - L’URL sera : `https://VOTRE-PSEUDO.github.io/volaille-services`

Astuce : si vous ne voyez pas le site au bout de 1–2 minutes, rechargez la page ou videz le cache.
